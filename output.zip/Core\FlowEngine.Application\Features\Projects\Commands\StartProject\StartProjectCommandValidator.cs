//using FlowEngine.Application.Interfaces;
//using FluentValidation;

//namespace FlowEngine.Application.Features.Projects.Commands.StartProject;

//public class StartProjectCommandValidator : AbstractValidator<StartProjectCommand>
//{
//    public StartProjectCommandValidator(ITranslator translator)
//    {
//        RuleFor(p => p.MyProperty)
//            .NotNull()
//            .WithName(p => translator[nameof(p.MyProperty)]);
//    }
//}