//using FlowEnginex.Application.Interfaces;
//using FluentValidation;

//namespace FlowEnginex.Application.Features.Jobs.Commands.DeleteJob;

//public class DeleteJobCommandValidator : AbstractValidator<DeleteJobCommand>
//{
//    public DeleteJobCommandValidator(ITranslator translator)
//    {
//        RuleFor(p => p.MyProperty)
//            .NotNull()
//            .WithName(p => translator[nameof(p.MyProperty)]);
//    }
//}