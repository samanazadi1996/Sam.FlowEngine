//using FlowEnginex.Application.Interfaces;
//using FluentValidation;

//namespace FlowEnginex.Application.Features.Jobs.Commands.UpdateJob;

//public class UpdateJobCommandValidator : AbstractValidator<UpdateJobCommand>
//{
//    public UpdateJobCommandValidator(ITranslator translator)
//    {
//        RuleFor(p => p.MyProperty)
//            .NotNull()
//            .WithName(p => translator[nameof(p.MyProperty)]);
//    }
//}