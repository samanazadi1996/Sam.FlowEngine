namespace FlowEngine.Application.Features.Projects.Queries.GetUserProjects;

public class GetUserProjectsResponse
{
    public string ProjectName { get; set; }
    public bool Started { get; set; }
}