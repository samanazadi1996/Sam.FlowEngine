//using FlowEngine.Application.Interfaces;
//using FluentValidation;

//namespace FlowEngine.Application.Features.Projects.Commands.StopProject;

//public class StopProjectCommandValidator : AbstractValidator<StopProjectCommand>
//{
//    public StopProjectCommandValidator(ITranslator translator)
//    {
//        RuleFor(p => p.MyProperty)
//            .NotNull()
//            .WithName(p => translator[nameof(p.MyProperty)]);
//    }
//}