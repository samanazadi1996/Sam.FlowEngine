//using FlowEngine.Application.Interfaces;
//using FluentValidation;

//namespace FlowEnginex.Application.Features.Jobs.Commands.UpdatePositionJob;

//public class UpdatePositionJobCommandValidator : AbstractValidator<UpdatePositionJobCommand>
//{
//    public UpdatePositionJobCommandValidator(ITranslator translator)
//    {
//        RuleFor(p => p.MyProperty)
//            .NotNull()
//            .WithName(p => translator[nameof(p.MyProperty)]);
//    }
//}